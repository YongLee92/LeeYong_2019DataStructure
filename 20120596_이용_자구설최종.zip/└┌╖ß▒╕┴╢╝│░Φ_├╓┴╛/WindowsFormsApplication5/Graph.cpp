#define _HAS_ITERATOR_DEBUGGING 0
#define _SECURE_SCL 0
#include "stdafx.h"
#include "Graph.h"
#include <iostream>
#include <queue>
#define MAX_STATION 500
#define M 10000
//�߾Ӵ��б�
//��ǻ�Ͱ��к�
//20120596
//�̿�

class compare{
public:int operator() (const pair<int, int>& p1, const pair<int, int>& p2){
		   return p1.second > p2.second;
	}
};

using namespace std;

Graph::Graph(){
	//���� �Է�

	wfstream file;
	file.imbue(locale("kor"));
	file.open("Info\\subway.txt", ios::in);
	
	match = new StationToInt[MAX_STATION];
	
	wchar_t buf[30];
	wchar_t buf2[30];
	int time;
	int id1;
	int id2;

	while (!file.eof()){
		file >> id1;
		file >> id2;
		file >> time;
		file >> buf;
		file >> buf2;

		for (int i = 0; i < wcslen(buf); i++){
			if (buf[i] == L' ')buf[i] = L'0';
		}
		for (int i = 0; i < wcslen(buf2); i++){
			if (buf2[i] == L' ')buf2[i] = L'0';
		}
		wcscpy(match[id1].name, buf);
		wcscpy(match[id2].name, buf2);

		map[id1][id2] = time;
		map[id2][id1] = time;
	}

	for (int i = 0; i < MAX_STATION; i++){
		for (int j = 0; j < MAX_STATION; j++){
			if (map[i][j] == 0)map[i][j] = M;
		}
	}
	file.close();
}



void Graph::DijkstraAlgorithm(int start){
	// start : ������ -> ����id
	int pos;
	int min;
	
	for (int i = 0; i < MAX_STATION; i++)distance[i] = M;

	for (int i = 0; i < MAX_STATION; i++){
		distance[i] = map[start][i];
	}
	bool check[MAX_STATION] = { false, };
	
	check[start] = true;

	
	for (int i = 1; i < MAX_STATION; i++){
		min = M;
		for (int j = 1; j < MAX_STATION; j++){
			if (!check[j] && min > distance[j]){
				min = distance[j];
				pos = j;
			}
		}
		check[pos] = true;

		for (int j = 1; j < MAX_STATION; j++){
			if (distance[j] > distance[pos] + map[pos][j]){
				distance[j] = distance[pos] + map[pos][j];
			}
		}
	}

}

int Graph::getMin(){
	int min = M;
	int min_id;
	for (int i = 0; i < MAX_STATION; i++){
		if (distance[i]!=M && min > distance[i]){ min = distance[i]; min_id = i; }
	}
	return min_id;
	
}

void Graph::setdistance(int num){
	distance[num] = M;
}

int Graph::getdistancenearby(int num){
	return distance[num];
}