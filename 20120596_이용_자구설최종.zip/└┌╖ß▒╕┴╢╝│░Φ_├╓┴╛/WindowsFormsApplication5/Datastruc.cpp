#define _HAS_ITERATOR_DEBUGGING 0
#define _SECURE_SCL 0
#include "stdafx.h"
#include "Datastruc.h"
#include "Graph.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <wchar.h>
#include <cstdlib>
//�߾Ӵ��б�
//��ǻ�Ͱ��к�
//20120596
//�̿�


using namespace std;
void Movie_data::Push_Mtheater(){



	wifstream data;

	data.open("Info\\location.csv");
	data.imbue(locale("kor"));
	
	wchar_t buf[30];
	while (!data.eof()){
		Theater* newtheater = new Theater();

		for (int j = 0; j <30; j++){
			newtheater->name[j] = 0;
		}
		
		
		///////////// ��ȭ�� �̸�
		data.getline(buf, 30, ',');
		wcscpy(newtheater->name, buf);
		//newtheater->name = theatertoInt(buf);
		/////////// �� �̸�
		data.getline(buf, 30, ',');
		for (int i = 0; i < wcslen(buf); i++){
			if (buf[i] == L' ')buf[i] = 0;
		}
		wcscpy(newtheater->station, buf);

		data.getline(buf, 30);
		wchar_t* pEnd;
		newtheater->st_to_theater = wcstod(buf, &pEnd);
		
		this->Mtheater.push_back(newtheater);
		this->numTheater++;
	}
	data.close();
}
//vector<Movie_theater> Mtheater;

void Movie_data::Push_Mname_time(){

	wfstream data;
	data.imbue(locale("kor"));
	data.open("Info\\moviedata.csv");

	int temp_time;
	int i = 0;
	int flag = 0;

	wchar_t buf[30];
	wchar_t moviename[30];
	wchar_t theatername[30];

	while (!data.eof()){


		for (int j = 0; j < 30; j++){
			buf[j] = 0;
			moviename[j] = 0;
			theatername[j] = 0;
		}

		Movie* newMovie = new Movie();
		//newMovie->time = 0;
		i = 0;
		flag = 0;
		///////////// ��ȭ�� �Է�
		data.getline(buf, 30, ',');
		
		wcscat(theatername, buf);

		//////////// ��ȭ���� �Է�
		data.getline(buf, 30, ',');
		wcscat(moviename, buf);

		//////////// �󿵽ð� �Է�
		data.getline(buf, 30);
		int time = 0;
		int hour = 0;
		int min = 0;
		int digit = 1;
		int pivotindex = 0;
		if (wcscmp(buf, L"")){
			for (pivotindex = wcslen(buf) - 1; pivotindex != -1; pivotindex--){
				if (buf[pivotindex] == L':'){//������ �� : �ε��� Ȯ��
					break;
				}
			}
			for (int i = wcslen(buf) - 1; i != -1;i--){
				if (i<pivotindex){//�ð� ����
					hour += (buf[i] - '0') * digit;
					digit *= 10;
				}
				else if (i == pivotindex){
					digit = 1;
				}
				else{//�� ����
					min += (buf[i] - '0')*digit;
					digit *= 10;
				}
			}
		}
		
		//while (temp_name != this->Mtheater[i].name){

		while (wcscmp(theatername, this->Mtheater[i]->name)){
			++i;
		}

	

		if (Mtheater[i]->fornext == NULL){//ù��° ����ϰ�� �迭 ���� �ٷ� �ٿ���
			Mtheater[i]->fornext = Make_Mname_time();

			this->current = Mtheater[i]->fornext;

			//this->current->name = temp_name;//���� �Է�
			wcscpy(this->current->name, moviename);
			this->current->hour = hour;
			this->current->min = min;
			this->current->next = NULL;//��������NULL�� ����Ű��
			for (int j = 0; j < Mname.size(); j++){
				if (!wcscmp(current->name, Mname[j])){
					flag = 1;
				}
			}
			if (flag == 0){
				Mname.push_back(current->name);
			}
		}
		else{
			
			this->current->next = Make_Mname_time();//ù��° ���ƴҰ�� current(���� �پ��մµ�����)�� next�� �������ְ� current�� �ٽ� ������ ��带 ����Ű����.
			this->current = this->current->next;

			//this->current->name = temp_name;//���� �Է�
			wcscpy(this->current->name, moviename);
			this->current->hour = hour;
			this->current->min = min;
			for (int j = 0; j < Mname.size(); j++){
				if (!wcscmp(current->name, Mname[j])){
					flag = 1;
				}
			}
			if (flag == 0){
				Mname.push_back(current->name);
			}
		}
	}
	data.close();
}

Movie* Movie_data::Make_Mname_time(){
	Movie* temp = new Movie();
	temp->next = NULL;
	return temp;
}
vector<Theater*> Movie_data::getMtheater(){
	return this->Mtheater;
}
vector<wchar_t*> Movie_data::getMovie(){
	vector<wchar_t*> out;
	for (int i = 0; i < Mname.size(); i++){
		out.push_back(Mname[i]);
	}
	return out;
}

void Movie_data::setstationid(int id){

}